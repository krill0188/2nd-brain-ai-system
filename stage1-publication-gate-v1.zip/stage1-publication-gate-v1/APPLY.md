# Stage 1-1 Publication Gate v1 — Apply Notes

Target repository: `krill0188/2nd-brain-ai-system`

Base commit verified on 2026-09-13:

`8ff794e80da5e041793b5dca9b2dbc99311b35e1`

Recommended branch:

`stage1/publication-gate-v1`

## Apply

```bash
cd ~/2nd
git status --short
git switch -c stage1/publication-gate-v1 8ff794e80da5e041793b5dca9b2dbc99311b35e1
git apply --check /path/to/stage1-publication-gate-v1.patch
git apply /path/to/stage1-publication-gate-v1.patch
python3 -m unittest discover -s tests -v
python3 scripts/build-publication-snapshot.py --dry-run --baseline-repo ~/projectm/drone-wiki-web
git status --short
```

Do not wire the snapshot into launchd/sync in this patch.
Do not merge until the dry-run report has been reviewed.
